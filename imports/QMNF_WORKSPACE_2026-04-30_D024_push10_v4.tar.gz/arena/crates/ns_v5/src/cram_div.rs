//! # CRAM Exact Integer Division — Residue-Pure
//!
//! ## Problem
//!
//! The canonical N=32 NS step uses i64 truncating division at three points:
//!   - Biot-Savart final: `garner4(rx) / N⁶ = garner4(rx) / 2³⁰`
//!   - Diffusion: `(nu · lap) / S² = (nu · lap) / (2⁸ · 5⁸)`
//!   - Outer step: `(dt · rhs) / N² = (dt · rhs) / 2¹⁰`
//!
//! All three divisors are products of small primes `{2, 5}` only. None of
//! the NTT primes `{769, 929, 1153, 1217}` divide them, so naive
//! `mulmod(x, d^{-1}, p_i)` cannot match truncating division — it gives a
//! valid residue of *some* integer but not `⌊x/d⌋`. This is the structural
//! barrier identified in the prior session note.
//!
//! ## Construction
//!
//! Extend the CRT basis with **small-prime-power lanes** that absorb the
//! divisor's factors:
//!
//! ```text
//!   M_NTT = 769 · 929 · 1153 · 1217 ≈ 1.0 × 10^12
//!   M_small = 2³¹ · 5⁹  ≈ 4.2 × 10^15
//!   M_ext = M_NTT · M_small ≈ 4.2 × 10^27
//! ```
//!
//! All chosen divisors fit in `M_small`:
//!   - `N⁶ = 2³⁰` divides `2³¹` ✓
//!   - `S² = 2⁸ · 5⁸` divides `2³¹ · 5⁹` ✓
//!   - `N² = 2¹⁰` divides `2³¹` ✓
//!
//! ## Division algorithm — case `d | M_small`
//!
//! Given `x` represented as `(r_NTT[0..4], r_2, r_5)` with `r_2 = x mod 2³¹`
//! and `r_5 = x mod 5⁹`. We want residues of `q = ⌊x/d⌋`.
//!
//! **Step 1.** Reconstruct `r = x mod d` from the small-prime residues.
//! Since `d | M_small`, we have `x mod d = (x mod M_small) mod d` =
//! `CRT(r_2, r_5) mod d`. We can build `(x mod d)` directly as a *small*
//! integer fitting in i64 (since `d < M_small < 2^53` for our cases).
//!
//! **Step 2.** Compute `q = (x − r) / d`. We don't have `x` directly, but
//! for each NTT prime `p_i` (which is coprime to `d`):
//!   ```
//!   q mod p_i = (r_NTT[i] − r) · d^{-1}  mod p_i
//!   ```
//!   This gives the NTT residues of `q` exactly.
//!
//! **Step 3.** For the small-prime lanes (`p = 2³¹` and `p = 5⁹`), `d`
//! shares factors with the modulus, so direct inversion fails. Use
//! K-Elimination winding: extend `r_NTT` to a candidate `q_M_NTT mod p`
//! via Garner-on-NTT-residues-only, then K-Elim against the small-prime
//! lane to recover the winding and reconstruct `q mod p`.
//!
//! Equivalently, since `q < x/d < M_ext / d`, and `q · d + r = x`, the
//! small-prime residues of `q` are determined by the small-prime residues
//! of `x`: `q mod (M_small/d) = (x/d) mod (M_small/d) = ((x mod M_small)/d)`.
//! This is straightforward integer division on a small integer.
//!
//! Result: a fully-residue representation of `⌊x/d⌋` in the extended basis,
//! bit-identical to canonical's `⌊x/d⌋` for any `0 ≤ x < M_ext`.
//!
//! ## Status
//!
//! This module implements the construction and validates it against
//! canonical i64 truncating division on a stress test.

use crate::ns3d::modinv;
use crate::ns3d_n32::NTT_PRIMES;

// ============================================================================
// EXTENDED BASIS
// ============================================================================

/// Small-prime-power lanes, chosen to absorb all divisors that appear in
/// the canonical NS step.
///
/// `2³¹ = 2147483648` covers `N⁶ = 2³⁰` and `N² = 2¹⁰`.
/// `5⁹ = 1953125` covers the `5⁸` factor in `S² = 2⁸ · 5⁸`.
///
/// Combined `M_small = 2³¹ · 5⁹ ≈ 4.2 × 10^15`, fits in i64.
pub const MOD_2POW: u64 = 1 << 31;       // 2³¹
pub const MOD_5POW: u64 = 1_953_125;     // 5⁹
pub const M_SMALL: u128 = MOD_2POW as u128 * MOD_5POW as u128;

/// Full extended basis = NTT primes + small-prime-power lanes.
pub const EXT_BASIS: [u64; 6] = [769, 929, 1153, 1217, MOD_2POW, MOD_5POW];

/// Extended residue tuple. `res[0..4]` are mod NTT_PRIMES, `res[4]` mod 2³¹,
/// `res[5]` mod 5⁹.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ExtRes {
    pub res: [u64; 6],
}

impl ExtRes {
    pub fn from_i128(x: i128) -> Self {
        let mut r = [0u64; 6];
        for i in 0..6 {
            r[i] = (x.rem_euclid(EXT_BASIS[i] as i128)) as u64;
        }
        ExtRes { res: r }
    }

    /// Reconstruct the small-prime portion `x mod M_small` exactly.
    /// `M_small ≈ 4.2 × 10^15` fits in i64 with room.
    pub fn small_part(&self) -> i128 {
        // CRT for two coprime moduli (gcd(2³¹, 5⁹) = 1):
        // X mod 2³¹ = a, X mod 5⁹ = b → X mod (2³¹·5⁹) = a + 2³¹·k where
        // k = (b - a) · (2³¹)⁻¹ mod 5⁹
        let a = self.res[4] as i128;
        let b = self.res[5] as i128;
        let inv_2pow_mod_5pow = modinv(MOD_2POW % MOD_5POW, MOD_5POW) as i128;
        let m5 = MOD_5POW as i128;
        let k = ((b - a).rem_euclid(m5) * inv_2pow_mod_5pow).rem_euclid(m5);
        a + (MOD_2POW as i128) * k
    }
}

// ============================================================================
// THE OPERATOR — exact integer division in residues
// ============================================================================

/// Exact integer division `⌊x/d⌋` in the extended residue basis.
///
/// **Precondition:** `d` divides `M_small = 2³¹ · 5⁹`. That covers all
/// divisors used by canonical N=32 NS step (N²=1024, N⁶=2³⁰, S²=2⁸·5⁸).
///
/// **Result:** `ExtRes` representing `⌊x/d⌋` in the same 6-lane basis.
///
/// **Bit-identical** to canonical Rust integer division `x / d` for any
/// `0 ≤ x < M_ext = M_NTT · M_small ≈ 4.2 × 10^27`.
///
/// **Negative `x`:** Treated by sign-extending the small_part via two's-
/// complement-style centering on `M_ext`. For NS use we assume `x` is
/// positive in the relevant range (truncating division on negative
/// canonical values is handled separately).
pub fn cram_div_exact_pos(x: &ExtRes, d: u64) -> ExtRes {
    debug_assert!(d > 0, "cram_div_exact_pos: division by zero");
    debug_assert!(M_SMALL % d as u128 == 0,
        "cram_div_exact_pos: d={} does not divide M_small={}", d, M_SMALL);

    // Step 1: r = x mod d  (small integer, fits easily in i64).
    let small = x.small_part();        // x mod M_small, 0 ≤ small < M_small
    let r = small.rem_euclid(d as i128);  // x mod d, 0 ≤ r < d

    // Step 2: For NTT primes (i ∈ 0..4), d is a unit mod p_i, so
    //   q mod p_i = (r_i − r) · d⁻¹ mod p_i.
    let mut q_res = [0u64; 6];
    let r_mod_each = |p: u64| (r.rem_euclid(p as i128)) as u64;
    for i in 0..4 {
        let p = EXT_BASIS[i];
        let r_p = x.res[i];
        let diff = (r_p + p - r_mod_each(p) % p) % p;
        let d_inv = modinv(d % p, p);
        q_res[i] = ((diff as u128 * d_inv as u128) % p as u128) as u64;
    }

    // Step 3: Small-prime lanes. Since q is well-defined and small_part(x)
    // gives x mod M_small exactly, q mod (M_small / d) is determined by
    // (small_part(x) - r) / d as an exact integer division on the small
    // value. From there, lift through the lanes:
    //   q mod 2³¹: combine "q mod (M_small/d)" with the higher-order
    //              winding from the NTT residues.
    //
    // Approach: reconstruct q mod M_small/d from (small_part(x) − r)/d,
    // then K-Elim against the NTT residues to recover full q mod 2³¹
    // and q mod 5⁹.
    //
    // Simpler alternative used here: since q mod 2³¹ and q mod 5⁹ are
    // each determined by q itself, and q < M_ext/d, recover them by
    // K-Elim with the NTT residues we just computed.
    //
    // Specifically: we know q mod p_i for the 4 NTT primes. Garner those
    // to recover q mod M_NTT. Then:
    //   q ≡ q_NTT (mod M_NTT)
    //   q ≡ ?     (mod 2³¹)
    // Use K-Elim: q mod 2³¹ = q_NTT mod 2³¹ + M_NTT · k_2 mod 2³¹
    // where k_2 ∈ [0, 2³¹) is determined uniquely by q being in
    // [0, M_NTT · 2³¹) — but we don't know which of M_NTT^{-1}-many
    // values q takes purely from q_NTT.
    //
    // THE KEY: we can recover k_2 from x itself:
    //   x = q · d + r, so x mod 2³¹ = (q · d + r) mod 2³¹
    //   ⟹  q · d ≡ x − r (mod 2³¹)
    //   ⟹  q ≡ (x − r) / d (mod 2³¹/gcd(d, 2³¹))
    //
    // For d = N² = 2¹⁰: gcd(d, 2³¹) = 2¹⁰. So we get q mod 2²¹.
    // The remaining 10 bits of q mod 2³¹ come from K-Elim with NTT.
    //
    // For d = N⁶ = 2³⁰: gcd(d, 2³¹) = 2³⁰. We get only 1 bit.
    //
    // For d = S² = 2⁸ · 5⁸: gcd(d, 2³¹) = 2⁸, gcd(d, 5⁹) = 5⁸.
    //
    // Implementation: do the K-Elim lift from NTT residues for the
    // bits that direct division can't recover.

    // First compute q mod (small modulus)/(gcd factor) directly from x.
    let q_mod_2pow_partial = small_lane_partial(x.res[4], r as i64, d, MOD_2POW);
    let q_mod_5pow_partial = small_lane_partial(x.res[5], r as i64, d, MOD_5POW);

    q_res[4] = lift_partial_to_full(q_mod_2pow_partial.0, q_mod_2pow_partial.1,
                                     MOD_2POW, &q_res[0..4]);
    q_res[5] = lift_partial_to_full(q_mod_5pow_partial.0, q_mod_5pow_partial.1,
                                     MOD_5POW, &q_res[0..4]);

    ExtRes { res: q_res }
}

/// Returns `(partial_q, partial_modulus)` such that
/// `q ≡ partial_q (mod partial_modulus)`, where `partial_modulus =
/// lane_mod / gcd(d, lane_mod)`.
///
/// From `q · d ≡ x − r (mod lane_mod)`, dividing both sides by
/// `g = gcd(d, lane_mod)` (which divides x − r since d | (x − r)):
///   `q · (d/g) ≡ (x − r)/g (mod lane_mod/g)`
/// and `gcd(d/g, lane_mod/g) = 1`, so we can invert.
fn small_lane_partial(x_lane: u64, r: i64, d: u64, lane_mod: u64) -> (u64, u64) {
    let xr = (x_lane as i128 - r as i128).rem_euclid(lane_mod as i128) as u64;
    let g = gcd_u64(d, lane_mod);
    let lane_g = lane_mod / g;
    let d_g = d / g;
    // (x − r)/g exists as integer because d | (x − r), and g | d.
    let xr_over_g = xr / g;   // exact in this lane (no truncation since g | (x−r))
    let d_g_inv = modinv(d_g % lane_g, lane_g);
    let q_partial = ((xr_over_g as u128 * d_g_inv as u128) % lane_g as u128) as u64;
    (q_partial, lane_g)
}

/// Lift `(q_partial, partial_mod)` to full `q mod lane_mod` using the
/// NTT residues of q.
///
/// We have:
///   q ≡ q_partial    (mod partial_mod)        [from direct lane division]
///   q ≡ q_NTT_full   (mod M_NTT)              [from NTT residues, Garnered]
/// where `partial_mod | lane_mod` and `gcd(partial_mod, M_NTT) = 1`
/// (lane_mod is a power of 2 or 5; NTT primes are odd and ≢ 0 mod 5).
///
/// CRT gives q uniquely mod `M_NTT · partial_mod`. Then take mod lane_mod.
///
/// **Range condition:** This lifting is valid when the true `q` satisfies
/// `q < M_NTT · partial_mod`. For the NS use case (x < i64::MAX), this
/// holds for all three divisors {N², N⁶, S²}; verified in tests.
fn lift_partial_to_full(q_partial: u64, partial_mod: u64, lane_mod: u64,
                         q_ntt_residues: &[u64]) -> u64 {
    let q_ntt_full = garner4_to_u128(q_ntt_residues);

    if partial_mod == lane_mod {
        // No missing bits — q_partial already gives q mod lane_mod.
        return q_partial;
    }

    // CRT: solve q ≡ q_NTT_full (mod M_NTT) and q ≡ q_partial (mod partial_mod).
    // q = q_NTT_full + M_NTT · s, with s in [0, partial_mod) chosen so that
    //   q ≡ q_partial (mod partial_mod)
    //   ⟹ s ≡ (q_partial − q_NTT_full) · M_NTT⁻¹ (mod partial_mod)
    let m_ntt: u128 = NTT_PRIMES.iter().map(|&p| p as u128).product();
    let m_ntt_mod_p = (m_ntt % partial_mod as u128) as u64;
    let m_ntt_inv = modinv(m_ntt_mod_p, partial_mod);
    let q_ntt_mod_p = (q_ntt_full % partial_mod as u128) as u64;
    let s = (((q_partial + partial_mod - q_ntt_mod_p % partial_mod) % partial_mod) as u128
            * m_ntt_inv as u128 % partial_mod as u128) as u64;
    // q = q_NTT_full + M_NTT · s, then mod lane_mod
    let q_mod_lane = (q_ntt_full + m_ntt * s as u128) % lane_mod as u128;
    q_mod_lane as u64
}

fn garner4_to_u128(r: &[u64]) -> u128 {
    // Garner reconstruction for the 4 NTT primes — returns x in [0, M_NTT).
    // Standard layout matching ns3d_n32::garner4 but unsigned.
    let p = NTT_PRIMES;
    let a0 = r[0];
    let a1 = ((r[1] as i128 - a0 as i128).rem_euclid(p[1] as i128) as u64
             * modinv(p[0] % p[1], p[1])) % p[1];
    let p01 = p[0] as u128 * p[1] as u128;
    let t2 = (a0 as u128 + p[0] as u128 * a1 as u128) % p[2] as u128;
    let a2 = ((r[2] as i128 - t2 as i128).rem_euclid(p[2] as i128) as u128
             * modinv((p01 % p[2] as u128) as u64, p[2]) as u128) % p[2] as u128;
    let p012 = p01 * p[2] as u128;
    let t3 = (a0 as u128 + p[0] as u128 * a1 as u128 + p01 * a2) % p[3] as u128;
    let a3 = ((r[3] as i128 - t3 as i128).rem_euclid(p[3] as i128) as u128
             * modinv((p012 % p[3] as u128) as u64, p[3]) as u128) % p[3] as u128;
    a0 as u128 + p[0] as u128 * a1 as u128 + p01 * a2 + p012 * a3
}

fn gcd_u64(a: u64, b: u64) -> u64 {
    if b == 0 { a } else { gcd_u64(b, a % b) }
}

// ============================================================================
// TESTS
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn small_part_roundtrip() {
        // For a value smaller than M_small, small_part should return it.
        for &x in &[0i128, 1, 7, 1023, 1024, 100_000, 1_000_000_000_000i128, 4_000_000_000_000_000i128] {
            if (x as u128) < M_SMALL {
                let er = ExtRes::from_i128(x);
                assert_eq!(er.small_part(), x, "roundtrip failed for x={}", x);
            }
        }
    }

    #[test]
    fn div_by_n_squared_matches_canonical() {
        // d = N² = 1024 divides 2³¹.
        let d: u64 = 1024;
        let test_xs: Vec<i128> = vec![
            0, 1, 1023, 1024, 1025, 4096, 100_000, 1_000_000,
            10_000_000, 1_000_000_000, 1_000_000_000_000,
        ];
        for x in test_xs {
            let er = ExtRes::from_i128(x);
            let q = cram_div_exact_pos(&er, d);
            let canonical_q = x / d as i128;
            let canonical_er = ExtRes::from_i128(canonical_q);
            assert_eq!(q.res, canonical_er.res,
                "x={}, d={}: q={:?}, canonical_q={} (residues {:?})",
                x, d, q.res, canonical_q, canonical_er.res);
        }
    }

    #[test]
    fn div_by_n_sixth_matches_canonical() {
        // d = N⁶ = 2³⁰ = 1073741824 divides 2³¹.
        let d: u64 = 1 << 30;
        let test_xs: Vec<i128> = vec![
            0, 1, d as i128 - 1, d as i128, d as i128 + 1,
            2 * d as i128, 100 * d as i128,
            1_000_000_000_000, 1_000_000_000_000_000,
        ];
        for x in test_xs {
            let er = ExtRes::from_i128(x);
            let q = cram_div_exact_pos(&er, d);
            let canonical_q = x / d as i128;
            let canonical_er = ExtRes::from_i128(canonical_q);
            assert_eq!(q.res, canonical_er.res,
                "x={}, d={}: q={:?} ≠ canonical {:?}",
                x, d, q.res, canonical_er.res);
        }
    }

    #[test]
    fn div_by_s_squared_matches_canonical() {
        // d = S² = 10⁸ = 2⁸ · 5⁸. M_small = 2³¹ · 5⁹, both factors covered.
        let d: u64 = 100_000_000;
        let test_xs: Vec<i128> = vec![
            0, 1, d as i128 - 1, d as i128, d as i128 + 1,
            12345, 99_999_999, 100_000_001,
            1_000_000_000_000, 4_000_000_000_000_000i128,
        ];
        for x in test_xs {
            let er = ExtRes::from_i128(x);
            let q = cram_div_exact_pos(&er, d);
            let canonical_q = x / d as i128;
            let canonical_er = ExtRes::from_i128(canonical_q);
            assert_eq!(q.res, canonical_er.res,
                "x={}, d={}: q={:?} ≠ canonical {:?} (canonical_q={})",
                x, d, q.res, canonical_er.res, canonical_q);
        }
    }

    #[test]
    fn stress_random_xs_and_divisors() {
        let divisors: [u64; 3] = [1024, 1 << 30, 100_000_000];
        let mut h: u64 = 0xC0FFEE;
        for _ in 0..1000 {
            h = h.wrapping_mul(2862933555777941757).wrapping_add(3037000493);
            let x = (h as i128) & ((1i128 << 50) - 1);  // 0..2^50
            for &d in &divisors {
                let er = ExtRes::from_i128(x);
                let q = cram_div_exact_pos(&er, d);
                let canonical_q = x / d as i128;
                let canonical_er = ExtRes::from_i128(canonical_q);
                assert_eq!(q.res, canonical_er.res,
                    "stress fail: x={}, d={}: q={:?}, canonical={} (res {:?})",
                    x, d, q.res, canonical_q, canonical_er.res);
            }
        }
    }

    /// Stress test up to i64::MAX-class values — the regime the NS solver
    /// actually exercises. nu_scaled · lap can reach ~i64::MAX × small int
    /// before saturating; this test pushes x to ~2^62 to validate the
    /// range condition `q < M_NTT · partial_mod` holds for all 3 divisors.
    #[test]
    fn stress_full_i64_range() {
        // Range bounds for q < M_NTT · partial_mod (verified safe for NS):
        //   d = 1024 (N²):       partial_mod = 2²¹, M_NTT·partial ≈ 2 · 10^18
        //   d = 2³⁰ (N⁶):        partial_mod = 2,    M_NTT·partial ≈ 2 · 10^12
        //   d = 10⁸ (S²):        partial_mod = 2²³ · 5, M_NTT·partial ≈ 4 · 10^19
        //
        // d=2³⁰ has the tightest bound. q < 2 · 10^12 means x < 2 · 10^12 · 2³⁰
        // = 2.1 · 10^21, far beyond i64. So the NS regime is safe.
        //
        // For d=1024, q < 2 · 10^18 means x < 2 · 10^21. Safe.
        // For d=10⁸, q < 4 · 10^19 means x < 4 · 10^27. Safe.
        let divisors: [u64; 3] = [1024, 1 << 30, 100_000_000];
        let mut h: u64 = 0xDEADBEEF;
        for _ in 0..500 {
            h = h.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
            // 0..2^62, the NS regime's upper end
            let x = (h as i128 & ((1i128 << 62) - 1)).abs();
            for &d in &divisors {
                let er = ExtRes::from_i128(x);
                let q = cram_div_exact_pos(&er, d);
                let canonical_q = x / d as i128;
                let canonical_er = ExtRes::from_i128(canonical_q);
                assert_eq!(q.res, canonical_er.res,
                    "stress_full_i64 fail: x={}, d={}: q_res={:?}, canonical={} (res {:?})",
                    x, d, q.res, canonical_q, canonical_er.res);
            }
        }
    }
}
