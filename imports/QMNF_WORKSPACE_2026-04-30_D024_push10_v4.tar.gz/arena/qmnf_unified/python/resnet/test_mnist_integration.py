#!/usr/bin/env python3
"""
MNIST Integration Test Script

Tests the MNIST loader for integer-only compliance and correct functionality.

Usage:
    python3 experiments/research/resnet/test_mnist_integration.py
"""

import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(project_root))

from experiments.research.resnet import (
    download_mnist,
    load_mnist_exemplars,
    load_mnist_test_set,
    normalize_image,
)


def test_exemplar_loading():
    """Test exemplar loading with integer-only compliance."""
    print("\n" + "="*60)
    print("TEST 1: Load Exemplars (Integer-Only Compliance)")
    print("="*60)

    try:
        # Load 1 exemplar per class
        exemplars = load_mnist_exemplars(count_per_class=1)

        # Verify count
        assert len(exemplars) == 10, f"Expected 10 exemplars, got {len(exemplars)}"
        print(f"✅ Loaded {len(exemplars)} exemplars")

        # Verify integer-only compliance
        for i, (image, label) in enumerate(exemplars):
            # Check image is list of ints
            assert isinstance(image, list), f"Image {i} type={type(image)}, expected list"
            assert all(isinstance(p, int) for p in image), f"Image {i} contains non-int pixels"

            # Check length (28*28 = 784 pixels)
            assert len(image) == 784, f"Image {i} length={len(image)}, expected 784"

            # Check pixel range
            assert all(0 <= p <= 255 for p in image), f"Image {i} pixels out of range [0, 255]"

            # Check label
            assert 0 <= label <= 9, f"Label {i}={label}, expected in [0, 9]"
            assert isinstance(label, int), f"Label {i} type={type(label)}, expected int"

            print(f"  Label {label}: pixels={len(image)}, "
                  f"range=[{min(image)}, {max(image)}]")

        print("✅ Integer-only compliance verified for all exemplars")

        return True

    except Exception as e:
        print(f"❌ Exemplar loading failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_test_set_loading():
    """Test test set loading."""
    print("\n" + "="*60)
    print("TEST 2: Load Test Set")
    print("="*60)

    try:
        # Load subset
        test_images, test_labels = load_mnist_test_set(limit=100)

        assert len(test_images) == 100, f"Expected 100 samples, got {len(test_images)}"
        assert len(test_labels) == 100, f"Expected 100 labels, got {len(test_labels)}"
        print(f"✅ Loaded {len(test_images)} test samples")

        # Verify format
        for i in range(min(5, len(test_images))):
            image = test_images[i]
            label = test_labels[i]

            assert isinstance(image, list), f"Sample {i} type={type(image)}"
            assert len(image) == 784, f"Sample {i} length={len(image)}"
            assert all(isinstance(p, int) for p in image), f"Sample {i} has non-int pixels"
            assert 0 <= label <= 9, f"Sample {i} label={label}"

            print(f"  Sample {i}: label={label}, pixels={len(image)}, "
                  f"range=[{min(image)}, {max(image)}]")

        print("✅ Test set format verified")

        return True

    except Exception as e:
        print(f"❌ Test set loading failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_normalize_image():
    """Test image normalization."""
    print("\n" + "="*60)
    print("TEST 3: Normalize Image")
    print("="*60)

    try:
        # Test with sample data
        test_image = [i for i in range(0, 256, 1)]  # [0, 1, 2, ..., 255]

        # Normalize to [0, 255] (should be identity)
        normalized = normalize_image(test_image, target_range=(0, 255))

        assert len(normalized) == len(test_image), "Length mismatch"
        assert all(isinstance(p, int) for p in normalized), "Non-int pixels"
        assert all(0 <= p <= 255 for p in normalized), "Pixels out of range"

        print(f"  Original range: [{min(test_image)}, {max(test_image)}]")
        print(f"  Normalized range: [{min(normalized)}, {max(normalized)}]")
        print("✅ Normalization preserves integer type")

        # Test with different range
        normalized_100 = normalize_image(test_image, target_range=(0, 100))
        assert all(0 <= p <= 100 for p in normalized_100), "Range [0, 100] violated"
        print(f"  Normalized to [0, 100]: range=[{min(normalized_100)}, {max(normalized_100)}]")
        print("✅ Custom range normalization works")

        return True

    except Exception as e:
        print(f"❌ Normalize image failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_download_helper():
    """Test download helper function."""
    print("\n" + "="*60)
    print("TEST 4: Download Helper")
    print("="*60)

    try:
        # This should just print instructions, not fail
        download_mnist()
        print("✅ Download helper executed")

        return True

    except Exception as e:
        print(f"❌ Download helper failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def run_all_tests():
    """Run all MNIST integration tests."""
    print("\n" + "="*60)
    print("MNIST INTEGRATION TEST SUITE")
    print("="*60)
    print("Testing integer-only MNIST dataset integration")
    print("Location: experiments/research/resnet/")
    print("="*60)

    results = []

    # Run tests
    results.append(("Exemplar Loading", test_exemplar_loading()))
    results.append(("Test Set Loading", test_test_set_loading()))
    results.append(("Normalize Image", test_normalize_image()))
    results.append(("Download Helper", test_download_helper()))

    # Print summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)

    passed = 0
    failed = 0

    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {test_name}")
        if result:
            passed += 1
        else:
            failed += 1

    print("="*60)
    print(f"Results: {passed}/{len(results)} tests passed")

    if failed == 0:
        print("\n🎉 All tests passed! MNIST integration ready for ResNet experiments.")
        print("\nNote: Using mock MNIST data (real data not downloaded).")
        print("To use real MNIST: Download CSV files as instructed by download_mnist().")
        return 0
    else:
        print(f"\n⚠️  {failed} test(s) failed. Please review output above.")
        return 1


if __name__ == "__main__":
    sys.exit(run_all_tests())
